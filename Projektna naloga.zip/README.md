# Hitrostno tipkanje

## Avtor
* Eva Strašek

## Opis
V tem projektu lahko preizkusiš kako hitro lahko v čim krajšem času natipkaš čim več besed.
Izbiraš lahko med težavnostmi:
 * zelo lahko
 * lahko
 * srednje
 * težko
